from selenium.webdriver.common.by import By
import time
def subpage(driver, num_big=1,num_small=0):
    # 打开菜单栏
    driver.find_element(By.CSS_SELECTOR, '.navbar-minimalize').click()
    time.sleep(1)
    # 关闭菜单栏
    driver.find_element(By.CSS_SELECTOR, '.navbar-minimalize').click()
    time.sleep(2)
    # 打开个人中心
    driver.find_element(By.CSS_SELECTOR, '.img-circle').click()
    time.sleep(1)
    # 关闭个人中心
    driver.find_element(By.CSS_SELECTOR, '[data-id="/system/user/profile"] > i').click()
    # 选中到菜单的每个小菜单，并用一个列表选中
    menus_big = driver.find_elements(By.CSS_SELECTOR, '#side-menu > li')
    while num_big < len(menus_big):
        if num_big == 1:
            menu = menus_big[num_big]
            menu.click()
            time.sleep(1)
            driver.find_element(By.XPATH, '//ul[@id="side-menu"]/li[@class="active"]/ul/li').click()
            time.sleep(1)
        elif num_big < 5:
            menu = menus_big[num_big]
            menu.click()
            time.sleep(1)
            driver.find_element(By.XPATH, '//ul[@id="side-menu"]/li[@class="active"]/ul/li').click()
            time.sleep(1)
            driver.find_element(By.CSS_SELECTOR, ".menuTabs > div > a > i").click()
        elif num_big == 5:
            menu = menus_big[num_big]
            menu.click()
            time.sleep(1)
            menus_small = driver.find_elements(By.XPATH, '//ul[@id="side-menu"]/li[@class="active"]/ul/li')
            num_small = 0
            while num_small < len(menus_small):
                if num_small < 7:
                    menu = menus_small[num_small]
                    menu.click()
                    time.sleep(1)
                    driver.find_element(By.CSS_SELECTOR, ".menuTabs > div > a > i").click()
                    # time.sleep(1)

                else:
                    menu = menus_small[num_small]
                    menu.click()
                    time.sleep(1)
                num_small = num_small + 1

            time.sleep(1)
            # driver.find_element(By.CSS_SELECTOR, ".menuTabs > div > a > i").click()
        elif num_big > 5:
            menu = menus_big[num_big]
            menu.click()
            time.sleep(1)
            menus_small = driver.find_elements(By.XPATH, '//ul[@id="side-menu"]/li[@class="active"]/ul/li')
            num_small = 0
            while num_small < len(menus_small):
                if num_small < 8:
                    menu = menus_small[num_small]
                    menu.click()
                    time.sleep(4)
                    driver.find_element(By.CSS_SELECTOR, ".menuTabs > div > a > i").click()
                    time.sleep(1)

                else:
                    menu = menus_small[num_small]
                    menu.click()
                    time.sleep(1)
                num_small = num_small + 1
        num_big = num_big + 1

