from selenium.webdriver.common.by import By
import time

def log_in(driver):
    text_name = "admin"
    test_pw = "admin123"
    driver.get("http://127.0.0.1:8081/")
    time.sleep(2)
    # 输入用户名
    driver.find_element(By.CSS_SELECTOR, ".form-control").send_keys(text_name)
    # 输入密码
    driver.find_element(By.NAME, "password").send_keys(test_pw)
    # 记住用户名
    driver.find_element(By.CSS_SELECTOR,"#rememberme").click()
    # 登录按钮
    driver.find_element(By.CSS_SELECTOR,"#btnSubmit").click()
    time.sleep(2)
