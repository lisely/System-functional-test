from selenium import webdriver
import log_in
import subpage
import log_out
driver = webdriver.Chrome()
log_in.log_in(driver)
subpage.subpage(driver)
log_out.log_out(driver)
driver.quit()