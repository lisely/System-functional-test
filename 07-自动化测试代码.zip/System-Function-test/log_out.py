from selenium.webdriver.common.by import By
import time
def log_out(driver):
    while True:
        try:
            time.sleep(2)
            # 退出登录
            driver.find_element(By.CSS_SELECTOR,".text-danger").click()
        except:
            break